//<student ID>
#include "cachelab.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>

typedef struct {
    short v;
    unsigned long long tag;
    //there is no block, only tag
    //because this is simulate, not real read, write
    unsigned int LRU;
} Line;

typedef struct {
    Line* lines;
} Set;

typedef struct {
    Set* sets;
} Cache;

int s, E, b;
int S;

int hit = 0, miss = 0, eviction = 0;

FILE* trace;
Cache cache;

void SetCache(int argc, char* argv[]);
void Parse();
void Operate();
void SetLRU(Set* set, int lineNum);

int main(int argc, char* argv[])
{

    SetCache(argc, argv);

    Parse();

    printSummary(hit, miss, eviction);

    return 0;
}

void SetCache(int argc, char* argv[])
{
    int opt;
    while ((opt = getopt(argc, argv, "s:E:b:t:")) != EOF)
    {
        switch (opt)
        {
            case 's':
                s = atoi(optarg);
                break;

            case 'E':
                E = atoi(optarg);
                break;

            case 'b':
                b = atoi(optarg);
                break;
            
            case 't':
                trace = fopen(optarg, "r");
                break;
        }
    }

    if (s < 0 || E <= 0 || b < 0 || !trace) return;

    // TODO: Write your cache simulator code!

    return;
}

void Parse()
{
    char c;
    unsigned long long address;
    unsigned int size;

    while (fscanf(trace, " %c %llx,%u", &c, &address, &size) != EOF)
    {
        if (c == 'L' || c == 'M' || c == 'S') Operate(address);
        if (c == 'M') Operate(address); //load and store, twice
    }

    return;
}

void Operate(unsigned long long address)
{
    // TODO: Write your cache simulator code!
    // ...
    // ...
}

void SetLRU(Set* set, int lineNum)
{
    // TODO: Write your cache simulator code!
    // ...
    // ...
}
